package demopackage;


import java.util.Scanner;

/**
 * A simple class that shows the declaration of an array and its processing
 * with for-loops.
 * @author fsong
 * @version 1.0
 * Created on Sept. 22, 2107
 */
public class ArrayOfScores {

    /**
    Reads in a set of scores and shows how much each
    score differs from the highest score.
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        double[] score = new double[10];


        System.out.println("Enter " + score.length + " scores:");
        score[0] = keyboard.nextDouble();
        double max = score[0];
        for (int index = 1; index < score.length; index++) {
            score[index] = keyboard.nextDouble();
            if (score[index] > max) {
                //double temp = max;
                max = score[index];
            }
            //System.out.println("Show value of temp " + temp);
            //max is the largest of the values score[0],..., score[index].
        }
        //System.out.println("Show value for index: " + index);
        System.out.println("The max score is " + max);
        System.out.println("The scores are:");
        for (int index = 0; index < score.length; index++) {
            System.out.println(score[index] + " differs from max by "
                    + (max - score[index]));
        }
        
        //System.out.println("current index value:" + index);
        /*int input = 0;
        if(true){
           double input = 5.0;
        }*/
    }
}

