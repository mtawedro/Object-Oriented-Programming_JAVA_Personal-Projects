/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demopackage;

import java.util.ArrayList;

public class ArrayListDemo
{
    public static void main(String[] args)
    {
        ArrayList<Date> birthdays = new ArrayList<Date>( );

        birthdays.add(new Date(1, 1, 1990));
        birthdays.add(new Date(2, 2, 1990));
        birthdays.add(new Date(3, 3, 1990));

        System.out.println("The list contains:");
        for (int i = 0;  i < birthdays.size(); i++)
            System.out.println(birthdays.get(i));

        birthdays.remove(0);
        System.out.println("The list now contains:");
        for (int i = 0; i < birthdays.size(); i++)
            System.out.println(birthdays.get(i));
    }
}
