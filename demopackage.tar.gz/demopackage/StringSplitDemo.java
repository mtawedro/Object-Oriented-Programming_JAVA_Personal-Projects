/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demopackage;

import java.util.Scanner;

/**
 *
 * @author fsong
 */
public class StringSplitDemo
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);

        System.out.println("Enter your last name");
        System.out.println("followed by your first and middle names.");
        System.out.println("If you have no middle name,");
        System.out.println("enter \"None\".");
        String inputLine = keyboard.nextLine( );

        String delimiters = "[, ]+"; //Comma and blank space
        String[] names = inputLine.split(delimiters);

        String middleName = names[2];
        if (middleName.equalsIgnoreCase("None"))
            middleName = ""; //Empty string
        
        /*String middleName = "";
        if( names.length > 2 ) {
            middleName = names[2];
            if( middleName.equalsIgnoreCase("None"))
                middleName = "";
        }*/
        
        System.out.println("Hello " + names[1]
                               + " " + middleName + " " + names[0]);
     }
}

