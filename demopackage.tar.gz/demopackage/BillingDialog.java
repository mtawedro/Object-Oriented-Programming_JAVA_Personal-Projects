/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demopackage;

import java.util.Scanner;

public class BillingDialog
{
   public static void main(String[] args)
   {
        System.out.println("Welcome to the law offices of");
        System.out.println("Dewey, Cheatham, and Howe.");
        //Bill.RATE = 100.00;
        Bill yourBill = new Bill();
        //System.out.println(yourBill.RATE);
        yourBill.inputTimeWorked();
        yourBill.updateFee( );
        //yourBill.outputBill( );
        System.out.println(yourBill.toString());
        System.out.println("We have placed a lien on your house.");
        System.out.println("It has been our pleasure to serve you.");
     }
}

